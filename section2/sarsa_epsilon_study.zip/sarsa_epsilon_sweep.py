#!/usr/bin/env python3
"""Measure SARSA's time to first discover an optimal greedy policy.

Reuses the environment and *unchanged SARSA learning loop* from sarsa_sim.py.
The exact optimal Q values are computed by value iteration solely for evaluation.

Usage:
  python sarsa_epsilon_sweep.py --steps 2000 --seeds 30 \
      --epsilons 0,0.01,0.05,0.1,0.2,0.4,0.7,1 --out-dir epsilon_results

Requires: numpy, matplotlib (plus the existing sarsa_sim.py).
"""

from __future__ import annotations

import argparse
import csv
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import median

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from sarsa_sim import ACTIONS, NONTERMINAL, simulate, transition


@dataclass(frozen=True)
class RunResult:
    epsilon: float
    seed: int
    first_hit_step: int | None
    sustained_hit_step: int | None
    optimal_at_last_step: bool


def optimal_q_by_value_iteration(gamma: float, tol: float = 1e-13):
    """Exact-model evaluation only; the learner never uses these values."""
    v = {s: 0.0 for s in NONTERMINAL}
    for _ in range(100000):
        new_v = {}
        for s in NONTERMINAL:
            values = []
            for a in ACTIONS:
                s_next, r, terminal = transition(s, a)
                values.append(r + gamma * (0.0 if terminal else v[s_next]))
            new_v[s] = max(values)
        if max(abs(new_v[s] - v[s]) for s in NONTERMINAL) < tol:
            v = new_v
            break
        v = new_v
    else:
        raise RuntimeError("Value iteration did not converge")

    q_star = {}
    optimal_actions = {}
    for s in NONTERMINAL:
        q_star[str(s)] = {}
        for a in ACTIONS:
            s_next, r, terminal = transition(s, a)
            q_star[str(s)][a] = r + gamma * (0.0 if terminal else v[s_next])
        best = max(q_star[str(s)].values())
        optimal_actions[str(s)] = {
            a for a in ACTIONS if best - q_star[str(s)][a] <= 1e-10
        }
    return q_star, optimal_actions


def greedy_policy_is_optimal(q: dict, optimal_actions: dict, tie_tol: float = 1e-12) -> bool:
    """Every greedy choice must be optimal, at every nonterminal state.

    This also rejects an untrained 0/0 tie when only one action is truly optimal.
    """
    for s in NONTERMINAL:
        values = q[str(s)]
        highest = max(values.values())
        greedy_set = {a for a in ACTIONS if highest - values[a] <= tie_tol}
        if not greedy_set.issubset(optimal_actions[str(s)]):
            return False
    return True


def evaluate_trace(data: dict, optimal_actions: dict, window: int) -> tuple[int | None, int | None, bool]:
    """Snapshot Q_k is the table AFTER k SARSA/environment steps."""
    first_hit = None
    sustained_hit = None
    streak = 0
    last_is_optimal = False
    for k, q in enumerate(data["snapshots"]):
        last_is_optimal = greedy_policy_is_optimal(q, optimal_actions)
        if last_is_optimal:
            if first_hit is None:
                first_hit = k
            streak += 1
            if streak >= window and sustained_hit is None:
                sustained_hit = k - window + 1
        else:
            streak = 0
    return first_hit, sustained_hit, last_is_optimal


def run_sweep(epsilons: list[float], n_seeds: int, max_steps: int, alpha: float,
              gamma: float, base_seed: int, window: int) -> tuple[list[RunResult], dict]:
    q_star, optimal_actions = optimal_q_by_value_iteration(gamma)
    results = []
    for epsilon in epsilons:
        for i in range(n_seeds):
            seed = base_seed + i
            # Reuse precisely the same SARSA update, action selection, and resets.
            data = simulate(max_steps, alpha, gamma, epsilon, seed)
            first, sustained, at_end = evaluate_trace(data, optimal_actions, window)
            results.append(RunResult(epsilon, seed, first, sustained, at_end))
        hits = [r for r in results if r.epsilon == epsilon and r.first_hit_step is not None]
        print(f"epsilon={epsilon:5.3f}: first hit {len(hits):>3}/{n_seeds} seeds", flush=True)
    return results, {"q_star": q_star,
                     "optimal_actions": {k: sorted(v) for k, v in optimal_actions.items()}}


def summarize(results: list[RunResult], epsilons: list[float], max_steps: int) -> list[dict]:
    summary = []
    for epsilon in epsilons:
        runs = [r for r in results if r.epsilon == epsilon]
        first_hits = [r.first_hit_step for r in runs if r.first_hit_step is not None]
        # Unobserved first hitting times are right-censored at max_steps.
        restricted_times = np.array([
            max_steps if r.first_hit_step is None else r.first_hit_step for r in runs
        ], dtype=float)
        mean = float(np.mean(restricted_times))
        sem = float(np.std(restricted_times, ddof=1) / np.sqrt(len(runs))) if len(runs) > 1 else 0.0
        summary.append({
            "epsilon": epsilon,
            "seeds": len(runs),
            "max_steps": max_steps,
            "first_hit_count": len(first_hits),
            "first_hit_rate": len(first_hits) / len(runs),
            "mean_min_first_hit_or_budget": mean,
            "approx_95_ci_lower": max(0.0, mean - 1.96 * sem),
            "approx_95_ci_upper": min(float(max_steps), mean + 1.96 * sem),
            "median_first_hit_successes_only": median(first_hits) if first_hits else None,
            "sustained_hit_rate": sum(r.sustained_hit_step is not None for r in runs) / len(runs),
            "optimal_at_last_step_rate": sum(r.optimal_at_last_step for r in runs) / len(runs),
        })
    return summary


def plot_mean_first_hit(summary: list[dict], path: Path) -> None:
    """Restricted first hitting time: non-hits count as the specified budget."""
    x = [row["epsilon"] for row in summary]
    y = [row["mean_min_first_hit_or_budget"] for row in summary]
    low = [row["approx_95_ci_lower"] for row in summary]
    high = [row["approx_95_ci_upper"] for row in summary]
    fig, ax = plt.subplots(figsize=(7.6, 4.5))
    ax.plot(x, y, marker="o", linewidth=1.8, label="Mean min(first-hit step, budget)")
    ax.fill_between(x, low, high, alpha=0.18, label="Approx. 95% CI")
    ax.set(xlabel="Exploration rate epsilon", ylabel="Environment steps",
           title="Time to first optimal greedy policy")
    ax.set_xlim(min(x) - 0.02, max(x) + 0.02)
    ax.set_ylim(bottom=0)
    ax.grid(alpha=0.25)
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()
    fig.savefig(path, dpi=175)
    plt.close(fig)


def plot_success_rates(summary: list[dict], path: Path) -> None:
    x = [row["epsilon"] for row in summary]
    fig, ax = plt.subplots(figsize=(7.6, 4.5))
    ax.plot(x, [row["first_hit_rate"] for row in summary], marker="o", label="Reached at least once")
    ax.plot(x, [row["optimal_at_last_step_rate"] for row in summary], marker="s", label="Optimal at last step")
    ax.plot(x, [row["sustained_hit_rate"] for row in summary], marker="^", label="Optimal for confirmation window")
    ax.set(xlabel="Exploration rate epsilon", ylabel="Fraction of seeds",
           title="Probability of identifying an optimal greedy policy")
    ax.set_xlim(min(x) - 0.02, max(x) + 0.02)
    ax.set_ylim(-0.02, 1.04)
    ax.grid(alpha=0.25)
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()
    fig.savefig(path, dpi=175)
    plt.close(fig)


def plot_first_hit_cdf(results: list[RunResult], epsilons: list[float], max_steps: int,
                       path: Path) -> None:
    """P(first-hit step <= t); non-hits stay out of the CDF within the budget."""
    fig, ax = plt.subplots(figsize=(7.6, 4.5))
    for epsilon in epsilons:
        runs = [r for r in results if r.epsilon == epsilon]
        times = sorted(r.first_hit_step for r in runs if r.first_hit_step is not None)
        xs = [0] + times + [max_steps]
        ys = [0] + [i / len(runs) for i in range(1, len(times) + 1)] + [len(times) / len(runs)]
        ax.step(xs, ys, where="post", linewidth=1.5, label=f"epsilon={epsilon:g}")
    ax.set(xlabel="Environment steps", ylabel="Fraction of seeds that have reached optimal",
           title="First-hit cumulative distribution")
    ax.set_xlim(0, max_steps)
    ax.set_ylim(0, 1.03)
    ax.grid(alpha=0.25)
    ax.legend(loc="lower right", fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(path, dpi=175)
    plt.close(fig)


def write_rows(rows: list[dict], path: Path) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--steps", type=int, default=2000, help="Maximum environment steps per seed")
    parser.add_argument("--seeds", type=int, default=30, help="Independent runs per epsilon")
    parser.add_argument("--epsilons", default="0,0.01,0.03,0.05,0.1,0.2,0.4,0.7,1",
                        help="Comma-separated exploration probabilities")
    parser.add_argument("--alpha", type=float, default=0.45)
    parser.add_argument("--gamma", type=float, default=0.9)
    parser.add_argument("--seed", type=int, default=0, help="First random seed (increments across runs)")
    parser.add_argument("--window", type=int, default=50,
                        help="Consecutive optimal snapshots for the sustained-hit metric")
    parser.add_argument("--out-dir", default="epsilon_results")
    args = parser.parse_args()

    epsilons = sorted({float(x.strip()) for x in args.epsilons.split(",") if x.strip()})
    if not epsilons or any(not np.isfinite(e) or not 0 <= e <= 1 for e in epsilons):
        parser.error("epsilon must be within [0,1]")
    if args.steps < 1 or args.seeds < 1 or args.window < 1:
        parser.error("steps, seeds, and window must be >= 1")

    out_dir = Path(args.out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    results, model_info = run_sweep(epsilons, args.seeds, args.steps, args.alpha,
                                    args.gamma, args.seed, args.window)
    summary = summarize(results, epsilons, args.steps)
    write_rows([asdict(r) for r in results], out_dir / "epsilon_runs.csv")
    write_rows(summary, out_dir / "epsilon_summary.csv")
    plot_mean_first_hit(summary, out_dir / "epsilon_vs_steps.png")
    plot_success_rates(summary, out_dir / "epsilon_vs_success.png")
    plot_first_hit_cdf(results, epsilons, args.steps, out_dir / "epsilon_first_hit_cdf.png")
    metadata = {"config": vars(args), "optimal_policy": model_info["optimal_actions"],
                "optimal_q": model_info["q_star"],
                "criterion": "every greedy action in every nonterminal state must be optimal",
                "step_definition": "k transitions completed; Q_k is the snapshot after k updates",
                "censoring": "first hits not seen within the budget are not observed"}
    (out_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print("\nResults in", out_dir)
    print("epsilon | hit rate | mean min(first hit, budget)")
    for row in summary:
        print(f"{row['epsilon']:7.3f} | {row['first_hit_rate']:8.1%} | {row['mean_min_first_hit_or_budget']:8.1f}")


if __name__ == "__main__":
    main()
