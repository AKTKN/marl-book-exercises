#!/usr/bin/env python3
"""Small tabular SARSA simulator with an HTML trajectory viewer.

Python standard library only. A five-state line world is used:
  [s1: terminal +1]--[s2]--[s3: start]--[s4]--[s5: terminal +5]

Each environment transition consumes one learning time step. The SARSA target
is r + gamma * Q(s_next, a_next), with a_next sampled from epsilon-greedy
BEFORE updating Q(s, a). At terminal states the bootstrap term is zero.
"""

from __future__ import annotations

import argparse
import csv
import json
import random
from pathlib import Path

ACTIONS = ("L", "R")
NONTERMINAL = (2, 3, 4)
START = 3
REWARDS = {1: 1.0, 5: 5.0}


def policy_probabilities(q: dict, state: int, epsilon: float) -> dict[str, float]:
    """Epsilon-greedy, splitting exploitation probability over tied maximizers."""
    values = q[str(state)]
    best = max(values.values())
    maximizers = [a for a in ACTIONS if abs(values[a] - best) < 1e-12]
    return {
        a: epsilon / len(ACTIONS)
        + (1 - epsilon) / len(maximizers) * (a in maximizers)
        for a in ACTIONS
    }


def all_policies(q: dict, epsilon: float) -> dict[str, dict[str, float]]:
    return {str(s): policy_probabilities(q, s, epsilon) for s in NONTERMINAL}


def choose_action(q: dict, state: int, epsilon: float, rng: random.Random):
    """Sample via the usual epsilon-explore versus greedy branch."""
    values = q[str(state)]
    best = max(values.values())
    greedy_actions = [a for a in ACTIONS if abs(values[a] - best) < 1e-12]
    explored = rng.random() < epsilon
    action = rng.choice(ACTIONS if explored else greedy_actions)
    probability = policy_probabilities(q, state, epsilon)[action]
    return action, {"exploration_branch": explored, "selected_probability": probability}


def transition(state: int, action: str):
    assert state in NONTERMINAL and action in ACTIONS
    next_state = state + (1 if action == "R" else -1)
    reward = REWARDS.get(next_state, 0.0)
    done = next_state in REWARDS
    return next_state, reward, done


def simulate(steps: int, alpha: float, gamma: float, epsilon: float, seed: int) -> dict:
    if steps < 1 or not 0 < alpha <= 1 or not 0 <= gamma < 1 or not 0 <= epsilon <= 1:
        raise ValueError("Require steps >= 1, 0 < alpha <= 1, 0 <= gamma < 1, 0 <= epsilon <= 1")

    rng = random.Random(seed)
    q = {str(s): {a: 0.0 for a in ACTIONS} for s in NONTERMINAL}
    snapshots = [json.loads(json.dumps(q))]
    records = []
    state = None
    episode = 0
    episode_step = 0
    action = None
    action_selection = None

    for t in range(steps):
        if state is None:
            episode += 1
            episode_step = 0
            state = START
            action, action_selection = choose_action(q, state, epsilon, rng)

        before = json.loads(json.dumps(q))
        policy_before = all_policies(before, epsilon)
        next_state, reward, terminal = transition(state, action)

        if terminal:
            next_action, next_selection = None, None
            next_q = 0.0
        else:
            # In SARSA, a_{t+1} is sampled before updating Q(s_t, a_t).
            next_action, next_selection = choose_action(q, next_state, epsilon, rng)
            next_q = q[str(next_state)][next_action]

        old_q = q[str(state)][action]
        target = reward + gamma * next_q
        td_error = target - old_q
        new_q = old_q + alpha * td_error
        q[str(state)][action] = new_q

        after = json.loads(json.dumps(q))
        records.append({
            "t": t,
            "episode": episode,
            "episode_step": episode_step,
            "state": state,
            "action": action,
            "reward": reward,
            "next_state": next_state,
            "next_action": next_action,
            "terminal": terminal,
            "action_exploration_branch": action_selection["exploration_branch"],
            "action_probability_when_sampled": action_selection["selected_probability"],
            "old_q": old_q,
            "next_q": next_q,
            "target": target,
            "td_error": td_error,
            "new_q": new_q,
            "policy_before": policy_before,
            "policy_after": all_policies(after, epsilon),
        })
        snapshots.append(after)

        if terminal:
            state = None
            action, action_selection = None, None
        else:
            state = next_state
            action, action_selection = next_action, next_selection
            episode_step += 1

    return {
        "model": {
            "states": [1, 2, 3, 4, 5],
            "nonterminal_states": list(NONTERMINAL),
            "start": START,
            "terminal_rewards": REWARDS,
            "actions": list(ACTIONS),
            "deterministic": True,
        },
        "parameters": {"steps": steps, "alpha": alpha, "gamma": gamma, "epsilon": epsilon, "seed": seed},
        "records": records,
        "snapshots": snapshots,
    }


def write_csv(data: dict, path: Path) -> None:
    columns = [
        "t", "episode", "episode_step", "state", "action", "reward", "next_state",
        "next_action", "terminal", "action_exploration_branch", "action_probability_when_sampled",
        "old_q", "next_q", "target", "td_error", "new_q",
    ]
    for state in NONTERMINAL:
        for action in ACTIONS:
            columns.append(f"Q_after_s{state}_{action}")
        for action in ACTIONS:
            columns.append(f"pi_after_s{state}_{action}")

    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for i, r in enumerate(data["records"]):
            flat = {key: r[key] for key in columns if key in r}
            for state in NONTERMINAL:
                for action in ACTIONS:
                    flat[f"Q_after_s{state}_{action}"] = data["snapshots"][i + 1][str(state)][action]
                    flat[f"pi_after_s{state}_{action}"] = r["policy_after"][str(state)][action]
            writer.writerow(flat)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--steps", type=int, default=160, help="total environment/SARSA update steps")
    parser.add_argument("--alpha", type=float, default=0.45)
    parser.add_argument("--gamma", type=float, default=0.9)
    parser.add_argument("--epsilon", type=float, default=0.25)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--output", default="sarsa_sim.html", help="standalone output HTML path")
    args = parser.parse_args()

    data = simulate(args.steps, args.alpha, args.gamma, args.epsilon, args.seed)
    output = Path(args.output).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    template_path = Path(__file__).with_name("sarsa_viewer_template.html")
    template = template_path.read_text(encoding="utf-8")
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    output.write_text(template.replace("__SARSA_DATA_JSON__", payload), encoding="utf-8")
    csv_path = output.with_suffix(".csv")
    write_csv(data, csv_path)
    print(f"HTML: {output}\nCSV:  {csv_path}")


if __name__ == "__main__":
    main()
