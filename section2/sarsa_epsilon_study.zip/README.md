# SARSA simulator (5-state rover)

The simulator uses only the Python standard library. It generates a standalone HTML playback GUI and a CSV log.

## MDP

- States: `s1 — s2 — s3 — s4 — s5`
- Start state of each episode: `s3`
- Actions: `L` / `R`, deterministic movement to the adjacent state
- Entering `s1`: terminal, reward `+1`
- Entering `s5`: terminal, reward `+5`
- All other transitions: reward `0`
- `Q_0(s,a)=0` for states `s2,s3,s4` and actions `L,R`.

The environment is a small illustrative adaptation of the five-state Mars rover setting in the linked Qiita SARSA article, not a replica of the MIT Press book's more elaborate Mars Rover MDP.

## Run

Put `sarsa_sim.py` and `sarsa_viewer_template.html` in the same folder. Then:

```bash
python sarsa_sim.py
```

Or change settings:

```bash
python sarsa_sim.py --steps 300 --alpha 0.4 --gamma 0.9 --epsilon 0.1 --seed 12
```

This produces `sarsa_sim.html` (double-click to open in a browser) and `sarsa_sim.csv`. No web server or Python package installation is needed.

## GUI

- `Previous` / `Next`: inspect exactly one learning update.
- `Play`: animate the state transitions.
- Slider: jump directly to an update step.
- `Q_k(s,a)` plot: view both actions for a selected state, or all six series.
- Lower table: complete sample tuple, reward, Q before/after, TD target/error, and current epsilon-greedy policy at the updated state.

Index `t` in the history is the zero-based environment step. Snapshot `Q_k` means the estimates *after k updates*, so the selected row `t` changes `Q_t` into `Q_{t+1}`.

For nonterminal transitions, the next action `a_{t+1}` is sampled with the current epsilon-greedy policy **before** updating `Q(s_t,a_t)`, and is then carried over as the next step's actual action. On terminal transitions, the bootstrap term is zero.

Epsilon is fixed rather than decayed in this teaching example. Accordingly, no convergence to the deterministic optimal policy is claimed.

## Study: time to discover an optimal greedy policy versus epsilon

Requires `numpy` and `matplotlib` (for plotting). The new module imports
`simulate` and `transition` from `sarsa_sim.py`; no changes to the original
simulator are necessary.

```bash
pip install numpy matplotlib
python sarsa_epsilon_sweep.py --steps 2000 --seeds 30 --epsilons 0,0.01,0.03,0.05,0.1,0.2,0.4,0.7,1 --out-dir epsilon_results
```

The exact optimal policy is obtained independently by value iteration on the
known deterministic MDP, only to **evaluate** the learner. The learner itself
still receives sampled `(s, a, r, s_next)` transitions and uses the unchanged
SARSA update in `simulate`.

At each learning step `k`, the module checks whether the greedy actions induced
by `Q_k` are all optimal in **every** nonterminal state `s2, s3, s4`. Tied
maximizers are allowed only if every tied action is optimal. `first_hit_step`
is the number of transitions completed before this first occurs; it is *not*
a guarantee of convergence. `sustained_hit_step` is the start of the first
window of 50 consecutive optimal snapshots (configurable by `--window`).

Outputs:

- `epsilon_runs.csv`: per-seed first-hit step, sustained-hit step, final optimality.
- `epsilon_summary.csv`: fraction of seeds that hit, hit time restricted to the
  training budget, approximate 95% CI, sustained-hit and final-optimal rates.
- `epsilon_vs_steps.png`: mean `min(first_hit, budget)` versus epsilon. An
  unreached run contributes the budget (right-censored).
- `epsilon_vs_success.png`: first-hit, sustained-hit, and final-optimal fractions.
- `epsilon_first_hit_cdf.png`: fraction of runs that first hit by time `t`.
- `metadata.json`: experiment arguments and exact optimal Q values.

The observed policy is the **greedy** policy extracted from Q. For fixed
`epsilon > 0`, the epsilon-greedy *behavior* policy continues exploring;
its policy/value does not generally converge to the optimal deterministic
policy/value. Thus a first-hit is different from SARSA convergence to `Q*`.
